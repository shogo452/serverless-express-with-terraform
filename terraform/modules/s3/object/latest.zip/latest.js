// The Lambda function source code is managed at /lambda_source
